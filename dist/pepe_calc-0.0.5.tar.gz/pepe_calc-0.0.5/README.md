# Simple Project - Enter Name Here

Foobar is a Python library for dealing with word pluralization.

## Installation

Use [pip](https://pip.pypa.io/en/stable/) to install -pepe_calc-.

```bash
pip install -pepe_calc-
```

## Usage

```python
import - pepe_calc -
```

## License
[MIT](https://choosealicense.com/licenses/mit/)